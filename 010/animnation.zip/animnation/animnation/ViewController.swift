//
//  ViewController.swift
//  animnation
//
//  Created by student on 2018/11/21.
//  Copyright © 2018年 wl. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myview: UIView!
    @IBOutlet weak var myview2: UIView!
    
    @IBAction func btnClicked(_ sender: Any) {
        UIView.animate(withDuration: 4, delay: 1, options: [.curveLinear,.autoreverse], animations: {
            //self.myview.alpha = 0
            self.myview.center.x = self.view.bounds.width
            self.myview.backgroundColor = UIColor.blue
            self.myview.frame = CGRect(x:400, y: 100, width: 20, height: 20)
            self.myview.transform = CGAffineTransform(rotationAngle: CGFloat(Double.pi))
            self.myview.transform = CGAffineTransform.identity
            self.myview.transform = CGAffineTransform(rotationAngle: CGFloat(Double.pi))
            self.myview.transform = CGAffineTransform.identity
            self.myview.transform = CGAffineTransform(rotationAngle: CGFloat(Double.pi))
            self.myview.transform = CGAffineTransform.identity
            self.myview.transform = CGAffineTransform(rotationAngle: CGFloat(Double.pi))
            self.myview.transform = CGAffineTransform.identity
            self.myview.transform = CGAffineTransform(rotationAngle: CGFloat(Double.pi))
            self.myview.transform = CGAffineTransform.identity
            self.myview.transform = CGAffineTransform(rotationAngle: CGFloat(Double.pi))
            self.myview.transform = CGAffineTransform.identity
        }){ (finished) in
            if finished{
                self.myview.removeFromSuperview()
            }
        }
    }
    
    @IBAction func btnClicked2(_ sender: Any) {
        let imageView = UIImageView(frame: CGRect(x:120,y:120,width:100,height:100))
        imageView.image = UIImage(named:"image")
        UIView.transition(from: myview2, to: imageView, duration: 2, options: .transitionFlipFromRight, completion: nil)
    }
}

