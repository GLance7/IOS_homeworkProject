//
//  thirdViewController.swift
//  multiMVC11
//
//  Created by student on 2018/12/8.
//  Copyright © 2018年 wl. All rights reserved.
//

import UIKit
class thirdViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func close(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
}
