//
//  ViewController.swift
//  multiMVC11
//
//  Created by student on 2018/12/8.
//  Copyright © 2018年 wl. All rights reserved.
//

import UIKit
protocol StudentProtocol {
    func change(name:String,information:String)
}
class FirstViewController: UIViewController,StudentProtocol {
    var nametext=""
    var informationtext=""

    func change(name: String, information: String) {
        self.nametext = name
        self.informationtext = information
    }
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var information: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewWillAppear(_ animated: Bool) {
        name.text=nametext
        information.text=informationtext
    }
    @IBAction func showSecondVC(_ sender: Any) {
        nametext=name.text!
        informationtext=information.text!
        let secVC = UIStoryboard(name:"Main",bundle:nil).instantiateViewController(withIdentifier:"SecondVC") as! SecondViewController
        secVC.nametext = nametext
        secVC.informationtext = informationtext
        secVC.delegate = self
        self.navigationController?.pushViewController(secVC, animated: true)
        //present(secVC,animated:true,completion:nil)
    }
    @IBAction func showThirdVC(_ sender: Any) {
        let thirVC = UIStoryboard(name:"Main",bundle:nil).instantiateViewController(withIdentifier:"ThirdVC")
        present(thirVC,animated:true,completion:nil)
    }
}

