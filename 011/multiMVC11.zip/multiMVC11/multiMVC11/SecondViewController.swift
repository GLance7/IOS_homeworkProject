//
//  SecondViewController.swift
//  multiMVC11
//
//  Created by student on 2018/12/8.
//  Copyright © 2018年 wl. All rights reserved.
//

import UIKit
class SecondViewController: UIViewController {
    var nametext=""
    var informationtext=""
    var delegate:StudentProtocol?
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var information: UITextField!
    override func viewDidLoad() {
       super.viewDidLoad()
        name.text=nametext
        information.text=informationtext
    }
    @IBAction func back(_ sender: Any) {
        nametext = name.text!
        informationtext = information.text!
        delegate?.change(name:nametext,information:informationtext)
        navigationController?.popViewController(animated: true)
       // dismiss(animated: true, completion: nil)
    }
}
