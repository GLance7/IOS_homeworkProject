//
//  ViewController.swift
//  Network
//
//  Created by student on 2018/12/13.
//  Copyright © 2018年 WL. All rights reserved.
//

import UIKit
import Alamofire
class ViewController: UIViewController {
    let url = URL(string:"http://t.weather.sojson.com/api/weather/city/101270101")!
    var weather:AnyObject!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func loadWithAF(_ sender: Any) {
        AF.request(url).responseJSON { (response) in
            self.weather = response.value as AnyObject
            self.performSegue(withIdentifier: "ShowWeatherList", sender: self)
        }
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ShowWeatherList" {
            if let secVC = segue.destination as? weatherTableViewController {
                secVC.weather = self.weather
            }
        }
    }
}
