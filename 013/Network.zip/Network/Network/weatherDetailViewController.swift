//
//  weatherDetailViewController.swift
//  Network
//
//  Created by student on 2018/12/13.
//  Copyright © 2018年 WL. All rights reserved.
//

import UIKit
class weatherDetailViewController: UIViewController {
    @IBOutlet weak var ymd: UILabel!
    @IBOutlet weak var week: UILabel!
    @IBOutlet weak var low: UILabel!
    @IBOutlet weak var high: UILabel!
    @IBOutlet weak var api: UILabel!
    @IBOutlet weak var type: UILabel!
    @IBOutlet weak var fk: UILabel!
    @IBOutlet weak var fl: UILabel!
    @IBOutlet weak var notice: UILabel!
    
    var weather:AnyObject!
    var infoData:AnyObject!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        infoData = ((((weather.object(forKey: "data") as AnyObject).object(forKey: "forecast")as! NSArray)[0])as AnyObject)
        ymd.text = infoData.object(forKey: "ymd") as? String
        week.text = infoData.object(forKey: "week") as? String
        low.text = infoData.object(forKey:"low") as? String
        high.text = infoData.object(forKey: "high") as? String
        api.text = infoData.object(forKey: "api") as? String
        type.text = infoData.object(forKey: "type") as? String
        fk.text = infoData.object(forKey: "fx") as? String
        fl.text = infoData.object(forKey: "fl") as? String
        notice.text = infoData.object(forKey: "notice") as? String
    }
    
}
