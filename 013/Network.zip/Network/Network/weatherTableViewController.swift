//
//  weatherTableViewController.swift
//  Network
//
//  Created by student on 2018/12/13.
//  Copyright © 2018年 WL. All rights reserved.
//

import UIKit
import Alamofire
class weatherTableViewController: UITableViewController {
    var weather:AnyObject!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.textLabel?.text = (weather.object(forKey: "cityInfo") as AnyObject).object(forKey: "city") as? String
        cell.detailTextLabel?.text = ((((weather.object(forKey: "data") as AnyObject).object(forKey: "forecast")as! NSArray)[0])as AnyObject).object(forKey: "ymd") as? String
        return cell
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ShowDetail" {
            if let detailVC = segue.destination as? weatherDetailViewController{
                detailVC.weather = self.weather
            }
        }
    }
}
