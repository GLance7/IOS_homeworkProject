import UIKit
//1.
func getDate(date: Date,zone: Int = 0) -> String {
    let format = DateFormatter()
    format.dateFormat = "yyyy年MM月dd日EEEE aa KK:mm"
    format.locale = Locale.current
    if zone >= 0{
        format.timeZone = TimeZone(abbreviation: "UTC+\(zone):00")
    }else{
        format.timeZone = TimeZone(abbreviation: "UTC\(zone):00")
    }
    let dateString = format.string(from: now)
    return dateString
}
let now = Date()
let beijing = getDate(date: now,zone: +8)
print("北京：\(beijing)")
let tokyo = getDate(date: now, zone: 9)
print("东京：\(tokyo)")
let newYork = getDate(date: now ,zone: -5)
print("纽约：\(newYork)")
let london = getDate(date:now)
print("伦敦：\(london)")

//2.
var str = "Swift is a powerful and intuitive programming language for iOS, OS X, tvOS, and watchOS."
let str1 = str[str.index(str.startIndex,offsetBy:6)...str.index(before:str.index(str.startIndex,offsetBy:20))]
print(str1)
let str2 = str.replacingOccurrences(of: "OS", with: "")
print(str2)

//3.
let dict = ["date": ["beijing": beijing, "tokyo": tokyo, "newYork": newYork, "london": london], "string": str2] as AnyObject

let defaultDoc = FileManager.default
if var path = defaultDoc.urls(for: .documentDirectory,in: .userDomainMask).first?.path{
    path.append("/test.txt")
    print(dict.write(toFile: path,atomically: true))
}

//4.
let image = try Data(contentsOf: URL(string:"https://ss0.bdstatic.com/5aV1bjqh_Q23odCf/static/superman/img/logo/bd_logo1_31bdc765.png")!)
if var url = defaultDoc.urls(for: .documentDirectory,in: .userDomainMask).first{
    url.appendPathComponent("image.png")
    try image.write(to: url)
}
//5.
let url = URL(string:"http://www.weather.com.cn/data/sk/101110101.html")!
let data = try Data(contentsOf: url)
let json = try JSONSerialization.jsonObject(with: data, options: .allowFragments)

if let dict = json as? [String:Any]{
    if let weather = dict["weatherinfo"] as? [String:Any]{
        let city = weather["city"]!
        let temp = weather["temp"]!
        let wd = weather["WD"]!
        let ws = weather["WS"]!
        print("城市：\(city),温度：\(temp),风向：\(wd),风力：\(ws)")
    }
}
