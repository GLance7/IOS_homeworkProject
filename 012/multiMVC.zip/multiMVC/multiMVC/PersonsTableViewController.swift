//
//  PersonsTableViewController.swift
//  multiMVC
//
//  Created by student on 2018/12/5.
//  Copyright © 2018年 wl. All rights reserved.
//

import UIKit
import CoreData

class PersonsTableViewController: UITableViewController {
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var persons:[Person]?
    fileprivate func reloadData() {
        let fetch:NSFetchRequest<Person> = Person.fetchRequest()
        persons = try? context.fetch(fetch)
         tableView.reloadData()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        print("******************"+NSHomeDirectory())
        reloadData()
    }
    override func viewWillDisappear(_ animated: Bool) {
         reloadData()
    }
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return persons?.count  ?? 0
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        if let p = persons?[indexPath.row]{
            cell.textLabel?.text = p.name
        }
        return cell
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        if segue.identifier == "Showdetail"{
//            let secVc = segue.destination as ! DetailViewController
//            if let indexPath = tableView.indexPath(for:sender as! UITableViewCell),let person = persons?[indexPath.row]
//            secVC.person = persons[]
//        }
    }
}
