//
//  ViewController.swift
//  multiMVC
//
//  Created by student on 2018/12/5.
//  Copyright © 2018年 wl. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    @IBOutlet weak var personId: UITextField!
    @IBOutlet weak var personName: UITextField!
    @IBOutlet weak var personPhone: UITextField!
    
    let appdelegate = UIApplication.shared.delegate as! AppDelegate
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func addPerson(_ sender: Any) {
        let person = Person(context:context)
        person.id = personId.text
        person.name = personName.text
        person.phone = personPhone.text
        dismiss(animated: true, completion: nil)
    }
    @IBAction func cancelPerson(_ sender: Any) {
         dismiss(animated: true, completion: nil)
    }
}

