//
//  SecondViewController.swift
//  multiMVC
//
//  Created by student on 2018/12/8.
//  Copyright © 2018年 wl. All rights reserved.
//

import UIKit
import CoreData
class SecondViewController: UIViewController {
    @IBOutlet weak var personId: UITextField!
    @IBOutlet weak var personName: UITextField!
    @IBOutlet weak var personphone: UITextField!
    let appdelegate = UIApplication.shared.delegate as! AppDelegate
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func searchPerson(_ sender: Any) {
        let fetch:NSFetchRequest<Person> = Person.fetchRequest()
        fetch.predicate = NSPredicate(format:"id=%@",personId.text!)
        let persons = try? context.fetch(fetch)
        if let p = persons?.first {
            personName.text = p.name
            personphone.text = p.phone
        }
    }
    @IBAction func cancelperson(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
}
