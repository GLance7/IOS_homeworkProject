//
//  ThirdViewController.swift
//  multiMVC
//
//  Created by student on 2018/12/8.
//  Copyright © 2018年 wl. All rights reserved.
//

import UIKit
import CoreData
class ThirdViewController: UIViewController {
    @IBOutlet weak var personId: UITextField!
    @IBOutlet weak var personname: UITextField!
    @IBOutlet weak var personphone: UITextField!
    let appdelegate = UIApplication.shared.delegate as! AppDelegate
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func updatepersn(_ sender: Any) {
        let fetch:NSFetchRequest<Person> = Person.fetchRequest()
        fetch.predicate = NSPredicate(format:"id=%@",personId.text!)
        let persons = try? context.fetch(fetch)
        if let p = persons?.first {
            p.name = personname.text
            p.phone = personphone.text
        }
        dismiss(animated: true, completion: nil)
    }
    @IBAction func deleteperson(_ sender: Any) {
        let fetch:NSFetchRequest<Person> = Person.fetchRequest()
        fetch.predicate = NSPredicate(format:"id=%@",personId.text!)
        let persons = try? context.fetch(fetch)
        if let p = persons?.first {
            context.delete(p)
        }
        dismiss(animated: true, completion: nil)
    }
    @IBAction func cancelPerson(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
}
