//
//  ViewController.swift
//  layout3
//
//  Created by student on 2018/10/25.
//  Copyright © 2018年 wl. All rights reserved.
//

import UIKit
class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        let orangeView = UIView()
        orangeView.backgroundColor = #colorLiteral(red: 0.9607843161, green: 0.7058823705, blue: 0.200000003, alpha: 1)
        let greenView = UIView()
        greenView.backgroundColor = #colorLiteral(red: 0.4666666687, green: 0.7647058964, blue: 0.2666666806, alpha: 1)
        let brownView = UIView()
        brownView.backgroundColor = #colorLiteral(red: 0.5058823824, green: 0.3372549117, blue: 0.06666667014, alpha: 1)
        let stackView = UIStackView(arrangedSubviews: [orangeView,greenView,brownView])
        stackView.axis = .vertical
        stackView.alignment = .fill
        stackView.distribution = .fillEqually
        stackView.spacing = 20
        view.addSubview(stackView)
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.leadingAnchor.constraint(equalTo:view.leadingAnchor,constant:20).isActive = true
        stackView.topAnchor.constraint(equalTo:view.topAnchor,constant:20).isActive = true
        stackView.trailingAnchor.constraint(equalTo:view.trailingAnchor,constant:-20).isActive = true
        stackView.bottomAnchor.constraint(equalTo:view.bottomAnchor,constant:-20).isActive = true
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

