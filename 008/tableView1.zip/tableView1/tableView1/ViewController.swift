//
//  ViewController.swift
//  tableView1
//
//  Created by student on 2018/11/29.
//  Copyright © 2018年 2016110441. All rights reserved.
//

import UIKit

class ViewController: UIViewController ,UITableViewDataSource,UITableViewDelegate{
    var students = [Student]()
    var teachers = [Teacher]()
    @IBOutlet weak var personTableView: UITableView!
    @IBOutlet weak var textInfor: UITextField!
    @IBOutlet weak var information: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        for i in 1...3{
            let temp = Teacher(firstName:"王",lastName:"\(i)",age:34,gender:.female,title:"hahaha+\(i)")
            teachers.append(temp)
        }
        for i in 1..<5{
            let temp = Student(firstName:"张",lastName:"\(i)",age:18,gender:.male,grade:99)
            students.append(temp)
        }
    }

//    默认只添加学生的姓名
    @IBAction func add(_ sender: Any) {
            if let studentsInfor = textInfor.text{
                students.append(Student(firstName: studentsInfor, lastName: " ", age: 22, gender: Gender.female, grade: 88))
                personTableView.reloadData()
                textInfor.resignFirstResponder()
            }
//            if let teachersInfor = textInfor.text{
//                teachers.append(Teacher(firstName: teachersInfor, lastName: "", age: 55, gender: Gender.male, title:"我是\(teachersInfor)"))
//                personTableView.reloadData()
//                textInfor.resignFirstResponder()
//            }
    }
//    默认只能编辑学生姓名
    @IBAction func edit(_ sender: Any) {
        if let row = personTableView.indexPathForSelectedRow?.row{
            if let name = textInfor.text{
                students[row].firstName = name
                personTableView.reloadData()
            }
        }
    }
    
    @IBAction func deleteInfor(_ sender: Any) {
         personTableView.isEditing = !personTableView.isEditing
    }

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return students.count + teachers.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row < students.count{
            let cell = (tableView.dequeueReusableCell(withIdentifier: "studentcell") as! StudentTableViewCell)
            let stu = students[indexPath.row]
            cell.name.text = stu.fullName
            cell.age.text = "\(stu.age)"
            cell.gender.text = "\(stu.gender)"
            cell.grade.text = "\(stu.grade)"
            return cell
        }else{
            let cell = (tableView.dequeueReusableCell(withIdentifier: "teachercell") as! TeacherTableViewCell)
            let tea = teachers[indexPath.row-students.count]
            cell.name.text = tea.fullName
            cell.age.text = "\(tea.age)"
            cell.gender.text = "\(tea.gender)"
            cell.title.text = "\(tea.title)"
            return cell
        }
    }
//    格子高度的大小
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    //删除
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            if indexPath.row < students.count {
                students.remove(at: indexPath.row)
                tableView.deleteRows(at: [indexPath], with: .fade)
            }else{
                teachers.remove(at: indexPath.row-students.count)
                tableView.deleteRows(at: [indexPath], with: .fade)
            }
            
        }
    }
//    选中后显示
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row < students.count{
            information.text = "\(students[indexPath.row])"
        }else{
            information.text = "\(teachers[indexPath.row-students.count])"
        }
    }
    func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
    }
//    拖动换行
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        let source = students.remove(at: sourceIndexPath.row)
        students.insert(source, at: destinationIndexPath.row)
    }
    
}

