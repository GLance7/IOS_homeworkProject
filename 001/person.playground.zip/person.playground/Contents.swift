import UIKit
enum Gender: Int{
    case male
    case female
    static func >(l:Gender,r:Gender) -> Bool {
        return l.rawValue > r.rawValue
    }
}
class Person: CustomStringConvertible {
    var firstName:String
    var lastName:String
    var age:Int
    var gender:Gender
    var fullName:String{
        get{
            return firstName+" "+lastName
        }
    }
    init(firstName:String,lastName:String,age:Int,gender:Gender){
        self.firstName = firstName
        self.lastName = lastName
        self.age = age
        self.gender = gender
    }
    convenience init(name:String){
        self.init(firstName:name,lastName:"",age:18,gender:Gender.female)
    }
    
    static func ==(l:Person,r:Person) -> Bool {
        return l.fullName == r.fullName && l.age == r.age && l.gender == r.gender
    }
    static func !=(l:Person,r:Person) -> Bool {
        return !(l==r)
    }
    
    var description:String{
        return "Name:\(fullName) Age:\(age) Gender:\(gender)"
    }
}
let p1=Person(firstName:"l",lastName:"gy",age:43,gender:Gender.male)
let p2=Person(name:"gyx")
print(p1.description)
print(p2.description)
class Teacher:Person{
    var title:String
    init(firstName:String,lastName:String,age:Int,gender:Gender,title:String){
        self.title = title
        super.init(firstName:firstName,lastName:lastName,age:age,gender:gender)
    }
    convenience init(name:String){
        self.init(firstName:name,lastName:"",age:36,gender:Gender.male,title:"Hello,i am a Teacher!")
    }
}
let t1=Teacher(name:"wang")
print(t1.description)

class Student:Person{
    var grade:Int
    init(firstName:String,lastName:String,age:Int,gender:Gender,grade:Int){
        self.grade = grade
        super.init(firstName:firstName,lastName:lastName,age:age,gender:gender)
    }
    convenience init(name:String){
        self.init(firstName:name,lastName:"",age:18,gender:Gender.female,grade:60)
    }
}
let s1=Student(name:"fan")
print(s1.description)

var array = [Person]()
for items in 1..<3{
    let temp = Person(firstName:"Person",lastName:"\(items)",age:20,gender:Gender.male)
    array.append(temp)
}
for items in 1...4{
    let temp = Teacher(firstName:"Teacher",lastName:"\(items)",age:23,gender:Gender.male,title:"haha")
    array.append(temp)
}
for items in 1...5{
    let temp = Student(firstName:"Student",lastName:"\(items)",age:30,gender:Gender.female,grade:60)
    array.append(temp)
}

var dict = ["Person":0,"Teacher":0,"Student":0]
for i in array{
    if i is Student{
        dict["Student"]? += 1;
    }
    else if i is Teacher{
        dict["Teacher"]? += 1;
    }
    else {
        dict["Person"]? += 1;
    }
}
print("*********dict content************")
for (key,value) in dict{
    print("\(key) 有 \(value) 个")
}
print("******age*********")
array.sort{ $0.age > $1.age}
for item in array {
    print(item)
}
print("***********fullName**********")
array.sort{$0.fullName > $1.fullName}
for item in array{
    print(item)
}
print("*******gender+age*********")
array.sort{($0.gender > $1.gender) && ($0.age > $1.age)}
for item in array{
    print(item)
}
