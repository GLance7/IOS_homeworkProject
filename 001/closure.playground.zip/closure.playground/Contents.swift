import UIKit
var primes = [Int]()
for i in 2...1000{
    var isPrime = true
    for j in 2..<i {
        if i%j == 0 {
            isPrime = false
        }
    }
    if isPrime{
        primes.append(i)
    }
}
print("***********")
print(primes)
primes.sort(by: >)
// 或primes.sort(by :{$0 > $1})
//或print(primes) primes.sort{(s1,s2) -> Bool in return s1>s2}
//或primes.sort(by:{ return $0 > $1})
//或primes.sort{$0>$1}
print(primes)
