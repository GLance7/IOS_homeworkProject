//
//  ViewController.swift
//  ScrollView
//
//  Created by student on 2018/11/7.
//  Copyright © 2018年 wl. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIScrollViewDelegate {

    @IBOutlet weak var scrollview: UIScrollView!
    @IBOutlet weak var pageControl: UIPageControl!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        for i in 1...7{
            let imageView = UIImageView(image: UIImage(named:"\(i)"))
            imageView.contentMode = .scaleAspectFit
            imageView.frame = CGRect(x:CGFloat(i-1) * scrollview.bounds.width,y:0,width:scrollview.bounds.width,height:scrollview.bounds.height)
            scrollview.addSubview(imageView)
            scrollview.isPagingEnabled = true
        }
     
       
        scrollview.contentSize = CGSize(width:7 * scrollview.bounds.width,height:scrollview.bounds.height)
//        scrollview.minimumZoomScale = 0.2
//        scrollview.maximumZoomScale = 5
        scrollview.delegate = self
        pageControl.numberOfPages = 7
        pageControl.currentPage = 0
        pageControl.isUserInteractionEnabled = true
        scrollview.showsVerticalScrollIndicator = false
    }
//    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
//        return scrollview.subviews.first
//        
//    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
         pageControl.currentPage = Int( scrollview.contentOffset.x / scrollview.bounds.width )
    }
    
    @IBAction func pageClicked(_ sender: UIPageControl) {
        let rect = CGRect(x:CGFloat(pageControl.currentPage) * scrollview.bounds.width,y:0,width:scrollview.bounds.width,height:scrollview.bounds.height)
        scrollview.scrollRectToVisible(rect, animated: true)
    }
    

}

