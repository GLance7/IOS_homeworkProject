import UIKit
import PlaygroundSupport

class Controller:UIViewController{
    override func loadView() {
        view = UIView(frame: CGRect(x: 0, y: 0, width: 400, height: 800))
        view.backgroundColor = UIColor.lightGray
        
        let manager = FileManager.default
        let document = manager.urls(for: .documentDirectory, in: .userDomainMask).first?.path
        let file = document?.appending("/image")
        print(document!)
        if manager.fileExists(atPath: file!){
            let image = file?.appending("/hehe.jpg")
            if manager.fileExists(atPath: image!){
                do{
                    let data = try Data(contentsOf: URL(fileURLWithPath: image!))
                    let img = UIImage(data: data)
                    let imageView = UIImageView(image: img)
                    imageView.frame = CGRect(x:0,y:100,width:400,height:300)
                    self.view.addSubview( imageView )
                }catch{
                    print(error)
                }
            }else{
                let url = URL(string: "http://pic.58pic.com/58pic/10/97/02/30a58PICH7N.jpg")
                do{
                    let data = try Data(contentsOf: url!)
                    try data.write(to:URL(fileURLWithPath: image!), options: .atomicWrite)
                    print("file not exists, build file successfuly")
                    print(data)
                }catch{
                    print(error)
                }
            }
        }else{
            do{
                try manager.createDirectory(atPath:file!,withIntermediateDirectories: true,attributes:nil)
                print("file not exists,build file successfuly!!!")
            }catch{
                print(error)
            }
        }
    }
}
let ct = Controller()
PlaygroundPage.current.liveView = ct
