import UIKit
import UIKit
import PlaygroundSupport

class MyView: UIView{
    override func draw(_ rect: CGRect) {
        let path = UIBezierPath(ovalIn: rect)
        UIColor.red.setStroke()
        path.stroke()
        UIColor.yellow.setFill()
        path.fill()
    }
}
class Controller:UIViewController{
    var oval:MyView!
    override func loadView() {
        view = UIView(frame: CGRect(x:0,y:0,width:400,height:800))
        view.backgroundColor = UIColor.green
        
        oval = MyView(frame: CGRect(x:100,y:100,width:150,height:100))
        oval?.backgroundColor = UIColor.clear
        view.addSubview(oval!)
    }
}
let ct = Controller()
PlaygroundPage.current.liveView = ct
