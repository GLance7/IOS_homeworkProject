import UIKit
// (1)
var dict = [["name":"wl","age":20],["name":"wll","age":30],["name":"wlll","age":40],["name":"wllll","age":50]]
let str = dict.map( { $0["age"]! } )
print(str)
//（2）
let arrString = ["haha","lala","123we","wawa","yaya","5443"]
let arrInt = arrString.filter({Int($0) != nil})
print(arrInt)
//（3）
var arr2 = arrString.reduce("",{$0 + "," + $1})
arr2.remove(at:arr2.startIndex)
print(arr2)
//（4）
var arr3 = [13,45,342,-90,0,48,98,100,-456,5643,234]
/*
 let maxnum = arr3.reduce(Int.min,max)
 let minnum = arr3.reduce(Int.max,min)
 let sum = arr3.reduce(0,+)
 print("Max:",maxnum," Min:",minnum," Sum:",sum)
 */
let all = arr3.reduce((max: arr3[0], min: arr3[0], sum: 0), { (max: max($0.max, $1), min: min($0.min, $1), $0.sum+$1) })
print(all)
//（5）
func f1(a:Int) -> Int {
    return a
}
func f2(a:String) -> Int{
    return Int(a)!
}
func f3() -> Int {
    return 2
}
func f4(a:Int){
    
}
func f5(a:Int) -> Int {
    return a+1
}
let funcArr:[Any] = [f1,f2,f3,f4,f5]
for (index,value) in funcArr.enumerated(){
    if value is (Int) -> Int {
        print(index)
    }
}
//（6）
extension Int{
    func sqrt() -> Double{
        return Darwin.sqrt(Double(self))
    }
}
print(4.sqrt())
//（7）
func getMaxandMin<T: Comparable>(a: T...) -> (T,T) {
    var max = a[0]
    var min = a[0]
    for item in a{
        if item > max {
            max = item
        }else if item < min{
            min = item
        }
    }
    return (max,min)
}
print(getMaxandMin(a:1,7,4,3,5))
print(getMaxandMin(a:1.2,5,6,4.5,8.9))
print(getMaxandMin(a:"d","bbf","f","h"))
